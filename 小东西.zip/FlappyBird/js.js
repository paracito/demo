var title=document.getElementById('title');
var beginScore=document.getElementById('beginScore');
var beginBtn=document.getElementById('beginBtn');
var bird=document.getElementById('bird');
var y=2;
var wrap=document.getElementById('wrap');
var img=document.getElementsByTagName('img');

function gameBegin(){
	beginBtn.onclick=function(){
		beginScore.style.display='none';
		title.style.display='none';
		beginBtn.style.display='none';
		bird.style.display = 'block';
		//小鸟往下掉
		birdMove(bird);
		createDuct();
		// collision();
	}
}
		
function birdMove(bird){
	var offTop=bird.offsetTop;
	var timer = setInterval(function(){
		offTop+=y;
		y+=0.5;
		if (y>=6) {
			y=6;
		}
		if (y<0) {
			bird.className='birdUp';
		}else{
			bird.className='birdDown';
		}
		bird.style.top=offTop+'px';
		if (offTop>=390) {
			offTop=390;
			clearInterval(timer);
			alert('gameover');
		}
	},30)
}

function tapWrap(){
	wrap.onclick=function(){
		y=-7;
	}
}

function random(min,max){
	return parseInt(Math.random()*(max-min)+(min+1));
}

function createDuct(){
	//每隔多长时间创建一组管道
	var timer=setInterval(function(){
		var duct=document.createElement('div');
		duct.className='duct';
		wrap.appendChild(duct);
		//添加上管道
		var up=document.createElement('div');
		up.className='upDuct';
		up.style.height=random(60,300)+'px';
		duct.appendChild(up);

		var upImg=document.createElement('img');
		upImg.src="img/pipe_up.png";
		up.appendChild(upImg);

		//添加下管道
		var down=document.createElement('div');
		down.className='downDuct';
		down.style.height = 430-up.offsetHeight+'px';
		duct.appendChild(down);

		var downImg=document.createElement('img');
		downImg.src="img/pipe_down.png";
		down.appendChild(downImg);
		ductMove(duct);

	function collision(){
		var bird_left=bird.offsetLeft;
		var bird_top=bird.offsetTop;
		var bird_width=bird.offsetWidth;
		var bird_height=bird.offsetHeight;

		var duct_left=duct.offsetLeft;
		var duct_top=duct.offsetTop;
		var duct_width=duct.offsetWidth;
		var up_height=up.offsetHeight;

		console.log(duct_left);
		console.log(duct_top);
		// console.log(bird_left);
		// console.log(bird_top);
		console.log(up_height);

		if ((duct_left)<=(bird_left+bird_width)<=(duct_left+duct_width+bird_width)){
			if ((duct_top+up_height)<bird_top<duct_top+up_height) {
				// alert('gameover');
				console.log('gameover');
			}
		}
	}
	collision();


	},3000);


}

//水管移动
function ductMove(duct){
	var offLeft=duct.offsetLeft;
	duct.move=setInterval(function(){
		offLeft-=1;
		duct.style.left=offLeft+'px';
	},20);
}

// function collision(){
// 	var up_duct=document.getElementsByClassName('upDuct');
// 	var down_duct=document.getElementsByClassName('downDuct');

// 	var bird_left=bird.offsetLeft;
// 	var bird_top=bird.offsetTop;
// 	var bird_width=bird.offsetWidth;
// 	var bird_height=bird.offsetHeight;

// 	var up_left=up_duct.offsetLeft;
// 	var up_top=up_duct.offsetTop;
// 	var up_width=up_duct.offsetWidth;
// 	var up_height=up_duct.offsetHeight;

// 	console.log(up_left);

// 	if ((up_left-bird_width)<=(bird_left+bird_width)<=(up_left+up_width+bird_width)){
// 		// if ((img_top+img_height)<bird_top<img_top+img_height) {
			
// 		// }else{
// 		// 	alert('gameover');
// 		// }
// 		alert('gameover');
// 	}
// }