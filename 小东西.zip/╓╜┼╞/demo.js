var start = document.getElementById('start');
var cardSite = document.getElementById('cardSite');
var header = document.getElementById('header');
var cardGet  = document.getElementById('cardGet');
var cardReceive = document.getElementsByClassName('cardReceive');//卡牌回收区
var cardList = document.getElementsByClassName('cardList');
var cardAmount = 13;//每种花色的卡牌数
var cardColor = ['a','b','c','d']//花色 方片 梅花 红心 黑桃
var cardInit = [];//初始化左上角卡片堆
var cardGetInit = [];//初始化左上角翻出的卡牌
var cardLeft = [];//发牌后剩余的卡牌
var cardChoose = [];//点击翻出的卡牌
var movingCard;//选中的卡牌
var movingCardArr = [];//移动多张卡牌
var movingFrom;//移动卡牌来源列

cardChoose.parent = cardGet;

//创建初始卡牌
function createCard(left,top){
	var addCard = document.createElement('div');
	addCard.classList.add('card');
	addCard.style.left = left + 'px';
	addCard.style.top = top + 'px';
	return addCard;
}
//初始化左上角卡牌堆
function initCard(){
	for(var i = 0; i < cardColor.length; i++){
		for(var j = 0; j < cardAmount; j++){
			var tempCard = createCard(20,10);
			tempCard.cardFlower = cardColor[i];
			tempCard.flowerValue = i;
			tempCard.num = j + 1;
			cardInit.push(tempCard);
			header.appendChild(tempCard);
		}
	}
	//乱序
	cardInit.sort(function(){
		return Math.random() >= 0.5 ? -1 : 1;
	});
}
//牌的移动
function cardMove(card, x, y, z, delay, parent){
	card.style.left = x + 'px';
	card.style.top = y + 'px';
	card.style.transition = 'left 0.2s ' + delay + 's, top 0.2s ' + delay +'s';
	card.parent = parent;
	card.style.zIndex = z;
	card.addEventListener('transitionend', function(){
		card.style.transition = null;
		if (parent.lastCard) {
			parent.lastCard.style.backgroundImage = 'url(img/' + card.cardFlower + '_' + card.num.toString(16) + '.png)';}
	})
}
//发牌
function sendCard(){
	//牌数计数
	var count = 0;
	//延迟计数
	var delayCount = 0;
	for(j = 0; j < cardList.length; j++){
		count = count + j + 1;
		cardList[j].lengthCount = 0;
		cardList[j].cardNumCount = j + 2;
		//遍历每一张牌
		for(i = count - 1; i < count + j + 1; i++){
			//手动构造类似数组添加函数
			cardList[j].add = function(card){
				if(this.lastCard){
					this.lastCard.next = card;
				}else {
					this.firstCard = card;
				}
				this.lastCard = card
				//模拟当前数组长度
				this.lengthCount += 1;
			};
			//手动构造类似数组移除函数
			cardList[j].remove = function(card){
				var pointer = this.firstCard;
				if (pointer == card) {
					this.firstCard = null;
					this.lastCard = null;
				}else {
					for(var a = 0; a < this.lengthCount - 2; a++){
						pointer = pointer.next;
					}
					// while(pointer.next){
					// 	pointer = pointer.next;
					// }
					pointer.next = null;
					this.lastCard = pointer;
				}
				this.lengthCount--;
				console.log(pointer.num);
				pointer.style.backgroundImage = 'url(img/' + pointer.cardFlower + '_' + pointer.num.toString(16) + '.png)';
			}
			//数组最长长度和当前长度比较
			if (cardList[j].lengthCount < cardList[j].cardNumCount) {
				delayCount++;
				cardList[j].add(cardInit[i]);
				//符合条件的卡牌移动
				cardMove(
					cardInit[i], 
					cardList[j].getBoundingClientRect().left, 
					cardList[j].getBoundingClientRect().top + (cardList[j].lengthCount - 1) * 35, 
					cardList[j].lengthCount, 
					0.05 * delayCount, 
					cardList[j]
				);
			}
		}
	}
}
var count = 0;
//发牌后剩余卡牌
function initCardLeft(){
	for(var i = 35; i < cardInit.length; i++){
		cardLeft.push(cardInit[i]);
		cardLeft[i-35].style.zIndex = '100' - i;
	}
	//点击换牌,牌堆互换
	cardSite.onclick = function(){
		if (cardLeft.length > 0) {
			cardLeft[0].style.transition = 'left 0.2s';
			cardLeft[0].style.left = '120px';
			cardLeft[0].style.backgroundImage = 'url(img/' + cardLeft[0].cardFlower + '_' + cardLeft[0].num.toString(16) + '.png)';
			cardLeft[0].style.zIndex = count;
			count++;
			cardChoose.push(cardLeft[0]);
			cardLeft.splice(0, 1);
			autoReceive();
		}else {
			for(var j = 0; j < count; j++){
				cardChoose[0].style.backgroundImage = 'url(img/blue.png)';
				cardChoose[0].style.left = '20px';
				cardChoose[0].style.transition = 'left 0.2s ' + 0.05 * j + 's';
				cardChoose[0].style.zIndex = 100 - j ;
				cardLeft.push(cardChoose[0]);
				cardChoose.splice(0, 1);
			}
			count = 0;
		}
	}
}
//能否捡起卡牌
function checkPickup(card){
	var pointer = card;
	while (pointer.next) {
		if (pointer.num - pointer.next.num == 1 && (pointer.flowerValue + pointer.next.flowerValue) % 2 == 1) {
			movingCardArr.push(pointer);
			pointer = pointer.next;
			// console.log(movingCardArr);
			// console.log('中间能捡起');
			continue;
		}else {
			// console.log('不能捡起');
			return false;
		}
	}
	movingCardArr.push(pointer);
	// console.log('最后一张能捡起');
	// console.log(movingCardArr);
	return true;
}
//能否放下卡牌
function checkPutdown(cardList){
	if (cardList.lastCard == null || cardList.lastCard.num - movingCard.num == 1 && (cardList.lastCard.flowerValue + movingCard.flowerValue) % 2 == 1) {
		// console.log('能够放下');
		return true;
	}
}
//游戏区自动回收
function autoReceive(){
	asd:
	for(var i = 0; i < cardColor.length; i++){
		cardReceive[i].lastNum = 0;
		cardReceive[i].addReceive = function(card){
			this.lastNum++;
			card.style.zIndex = this.lastNum;
			card.style.top = '10px';
			card.style.left = 986 + i * 95 + 'px';
			card.style.transition = 'left 0.2s, top 0.2s';
		};
		if (cardChoose.length > 0) {
			if (cardChoose[cardChoose.length - 1].flowerValue == i && cardChoose[cardChoose.length - 1].num - cardReceive[i].lastNum == 1){
				cardReceive[i].addReceive(cardChoose[cardChoose.length - 1]);
				cardChoose.splice(cardChoose.length - 1, 1);
			}
		}
		for(var j = 0; j < cardList.length; j++){
			if (cardList[j].lastCard) {
				if (cardList[j].lastCard.flowerValue == i && cardList[j].lastCard.num - cardReceive[i].lastNum == 1) {
					// var pointer = cardList[j].lastCard;
					cardList[j].lastCard.onmousedown = function(){
						return false;
					};
					cardReceive[i].addReceive(cardList[j].lastCard);
					cardList[j].remove(cardList[j].lastCard);
					// return false;
					break asd;
					// cardList[j].lastCard.style.backgroundImage = 'url(img/' + cardList[j].lastCard.cardFlower + '_' + cardList[j].lastCard.num.toString(16) + '.png)';
				}
			}
		}
	}
}
//错误卡牌退回原位
function goBack(card, i){
	if (movingFrom == cardGet) {
		card.style.top = '10px';
		card.style.left = '120px';
		card.style.zIndex = count - 1;
		// console.log('左上角卡牌');
	}else {
		card.style.top = movingFrom.getBoundingClientRect().top + (movingFrom.lengthCount - movingCardArr.length + i) * 35 + 'px';
		card.style.left = movingFrom.getBoundingClientRect().left + 'px';
		card.style.zIndex = movingFrom.lengthCount + i;
		// console.log('游戏区卡牌');
	}
}
//游戏初始化
function init(){
	initCard();
	initCardLeft();
}
//开始游戏
function begin(){
	init();
	sendCard();
	start.style.display = 'none';
	setTimeout('autoReceive()', 2500);
	// autoReceive();
	for(var i = 0; i < cardInit.length; i++){
		cardInit[i].onmousedown = function(e){
			if (checkPickup(this)) {
				movingCard = this;
				if (this.parent) {
					movingFrom = this.parent;
				}else {
					movingFrom = cardGet;
				}
				console.log('鼠标点下');
			}
		}
	}
	document.onmousemove = function(e){
		if (movingCardArr != null) {
			for(var i = 0; i < movingCardArr.length; i++){
					movingCardArr[i].style.left = (e.clientX - 40) + 'px';
					movingCardArr[i].style.top = (e.clientY + 30 * i - 20) + 'px';
					movingCardArr[i].style.zIndex = 100 + i;
					movingCardArr[i].style.transition = 'null';
			}
		}
	}
	document.onmouseup = function(e){
		if (movingCardArr == []) {
			console.log('没有选中牌');
			return false;
		}
		for(var i = 0; i < cardList.length; i++){
			if(e.clientX >= cardList[i].getBoundingClientRect().left && e.clientX <= cardList[i].getBoundingClientRect().left + 100 && e.clientY >cardList[i].getBoundingClientRect().top + (cardList[i].lengthCount - 1) * 35){
				if (checkPutdown(cardList[i])) {
					if (movingFrom == cardGet) {
						cardChoose.splice(cardChoose.length - 1, 1);
						for(var j = 0; j < movingCardArr.length; j++){
							cardList[i].add(movingCardArr[j]);
							movingCardArr[j].parent = cardList[i];
							movingCardArr[j].style.left = cardList[i].getBoundingClientRect().left + 'px';
							movingCardArr[j].style.top = cardList[i].getBoundingClientRect().top + (cardList[i].lengthCount - 1) * 35 + 'px';
							movingCardArr[j].style.zIndex = cardList[i].lengthCount + 1;
						}
					}else {
						for(var j = 0; j < movingCardArr.length; j++){
							movingFrom.remove(movingCardArr[j]);
							cardList[i].add(movingCardArr[j]);
							movingCardArr[j].parent = cardList[i];
							movingCardArr[j].style.left = cardList[i].getBoundingClientRect().left + 'px';
							movingCardArr[j].style.top = cardList[i].getBoundingClientRect().top + (cardList[i].lengthCount - 1) * 35 + 'px';
							movingCardArr[j].style.zIndex = cardList[i].lengthCount + 1;
						}
					}
					// console.log(movingCard.style.top);
					// console.log('移动成功');
					break;
				}else {
					for(var k = 0; k < movingCardArr.length; k++){
						goBack(movingCardArr[k], k);
					}
					// console.log('卡牌错误');
				}
			}else {
				for(var k = 0; k < movingCardArr.length; k++){
					goBack(movingCardArr[k], k);
				}
				// console.log('位置错误');
			}
		}
		movingCardArr = [];
		autoReceive();
	}
}



// 取消回收卡牌的点击事件
// 同时移动多张卡牌
// 自动回收卡牌更改问题