var table = document.getElementById('table');
var head = document.getElementById('head');
var cardLine = document.getElementsByClassName('card_line');
var card=[];//牌库
var cardType = {site:'site',card:'card'};
var cardSiteX = [0,120,240,360];
var cardSiteY = 20;
var cardReceiveX = [700,820,940,1060];
var cardReceiveY = 20;
var cardSite = [];//存牌区
var cardReceive = [];//回收牌区
var cardFlower = ['a','b','c','d'];//方片，梅花，红心，黑桃
var cardCount = 13;//每种花色十三张牌
var cardWidth = 80;
var movingCard = null;//移动中的卡牌
var movingFrom = null;//移动卡牌的来源

//判断游戏结束
function isFinish(){
	for (var i = 0 ; i < cardReceive.length ; i ++) {
        if (cardReceive[i].num < cardCount) {
            return false;
        }
    }
    return true;
}
//自动回收
function autoReceive(){
	var flag = true;
    var numCount = 0;
    while(flag) {
        flag = false;
        for (var i = 0 ; i < cardLine.length ; i ++) {
            if (cardLine[i].lastCard && cardLine[i].lastCard.num - cardReceive[cardLine[i].lastCard.flowerValue].num == 1){
                flag = true;
                var card = cardLine[i].lastCard;
                cardLine[i].remove(card);
                console.log("花色:" + card.flowerValue + ", 数值:" + card.num);
                cardReceive[card.flowerValue].push(card, 0.1 * numCount);
                numCount += 1;
            }
        }
        for (var i = 0 ; i < cardSite.length ; i ++) {
            if (cardSite[i].card && cardSite[i].card.num - cardReceive[cardSite[i].card.flowerValue].num == 1){
                flag = true;
                var card = cardSite[i].card;
                cardSite[i].remove(card);
                console.log("花色:" + card.flowerValue + ", 数值:" + card.num);
                cardReceive[card.flowerValue].push(card, 0.1 * numCount);
                numCount += 1;
            }
        }
    }
    if (isFinish()) {
        setTimeout(function () {
            alert("恭喜获胜");
        }, numCount * 100 + 200);
    }
}
//创建卡牌
function createCard(cardType,left,top){
	var card = document.createElement('div');
	card.classList.add(cardType);
	card.style.left = left +'px';
	card.style.top = top + 'px';
	return card;
}
//发牌的移动
function cardMove(card, x, y, zIndex, delay, parent){
	card.style.transition = 'left 0.2s' + delay + 's, top 0.2s' + delay + 's';
	card.style.left = x + 'px';
	card.style.top = y + 'px';
	card.selfCount = zIndex;
	card.parent = parent;
	card.addEventListener('transitionend', function(){
        this.style.zIndex = this.selfCount;
        this.style.transition = null;
	})
}
//链接数组
function linkedToArr(card) {
    var result = [];
    var pointer = card;
    while(pointer){
        result.push(pointer);
        pointer = pointer.next;
    }
    return result;
}
//错误放回
function goBack(){
	var cardArr = linkedToArr(movingCard);
    for (var j = 0 ; j < cardArr.length ; j ++) {
        movingFrom.push(cardArr[j], 0.1);
    }
    movingCard = null;
    movingFrom = null;
}
//判断能否拿起
function checkPickUp(card){
	var pointer = card;
	while (pointer.next) {
		if ((pointer.flowerValue + pointer.next.flowerValue) % 2 ==1 && pointer.num - pointer.next.num == 1) {
			pointer = pointer.next;
            continue;
		}else {
			return false;
		}
	}
	return true;
}
//判断能否放下
function checkPutDown(cardLine){
	if (cardLine.lastCard == null || (cardLine.lastCard.flowerValue + movingCard.flowerValue) % 2 == 1 && cardLine.lastCard.num - movingCard.num == 1) {
		return true;
	}
}
//发牌
function sendCard(){
	for(var i = 0; i < card.length; i++){
		cardLine[i % cardLine.length].push(card[i], 0.1 * i);
		card[i].onmousedown = function (e) {
            if (!checkPickUp(this)) {
                return;
            }
            movingCard = this;
            movingFrom = this.parent;
            this.parent.remove(this);
            e.stopPropagation();
        }
	}
	setTimeout(function () {
        autoReceive();
    }, 55 * 100);
}
//初始化游戏区
function initCardArea(){
	for(var i = 0; i < cardLine.length; i++){
		cardLine[i].count = 0;
		cardLine[i].index = i;
		cardLine[i].push = function(card, delay){
			cardMove(card, this.getBoundingClientRect().left + cardWidth / 2, this.getBoundingClientRect().top + 25 * this.count, this.count, delay, this);
			card.style.background = 'url(img/' + card.flowerColor + '_' + card.num.toString(16) + '.png)';
			card.style.backgroundSize = 'cover';
			card.next = null;
            this.count += 1;
            if (this.lastCard) {
                this.lastCard.next = card;
            } else {
                this.firstCard = card;
            }
            this.lastCard = card;
		};
		cardLine[i].remove = function(card){
			var pointer = this.firstCard;
			if (pointer == card) {
				this.firstCard = null;
				this.lastCard = null;
			}else {
				while (pointer.next != card) {
					pointer.next = pointer;
				}
				pointer.next = null;
                this.lastCard = pointer;
			}
			pointer = card;
            while(pointer) {
                this.count -= 1;
                pointer.count = 0;
                pointer.parent = null;
                pointer = pointer.next;
            }
		}
	}
}
//初始的牌，定花色，定大小
function initCard(){
	for(var i = 0; i < cardFlower.length; i++){
		for(var j = 0; j < cardCount; j++){
			var tempCard = createCard(cardType.card, head.getBoundingClientRect().left + head.getBoundingClientRect().width/2 - 40, 20);
			tempCard.flowerColor = cardFlower[i];
			tempCard.flowerValue = i;
			tempCard.num = j + 1;
			card.push(tempCard);
            table.appendChild(tempCard);
		}
	}
	//乱序
	card.sort(function(){
		return Math.random() >= 0.5? 1 : -1;
	});
	//层级
	for(var i = 0; i < card.length; i++){
		card[i].style.zIndex = 100 + i;
	}
}
//初始化存牌区
function initCardSite(){
	for(var i = 0; i <cardSiteX.length; i++){
		var tempSite = createCard(cardType.site, cardSiteX[i], cardSiteY);
		tempSite.push = function(card){
			if (this.card) {
                goBack();
                return;
            }
            this.card = card;
            cardMove(card, this.getBoundingClientRect().left, this.getBoundingClientRect().top, 0, 0, this);
		}
		tempSite.remove = function(){
			this.card = null;
		}
		head.appendChild(tempSite);
		cardSite.push(tempSite);
	}
}
//初始化回收区
function initCardReceive(){
	for(var i = 0; i <cardReceiveX.length; i++){
		var tempReceive = createCard(cardType.site, cardReceiveX[i], cardReceiveY);
		tempReceive.num = 0;
		tempReceive.push = function(card, delay){
			cardMove(card, this.getBoundingClientRect().left, this.getBoundingClientRect().top, this.num, delay, this);
			this.num += 1;
		}
		head.appendChild(tempReceive);
		cardReceive.push(tempReceive);
	}
}
//开始游戏
function begin(dom){
	sendCard();
	dom.remove();

	document.onmouseup = function(e) {
        if (movingCard == null) {
            return;
        }
        for (var i = 0 ; i < cardLine.length ; i ++) {
            if (e.clientX > cardLine[i].getBoundingClientRect().left && e.clientX < cardLine[i].getBoundingClientRect().width + cardLine[i].getBoundingClientRect().left && e.clientY > cardLine[i].getBoundingClientRect().top) {
                if (!checkPutDownRule(cardLine[i])) {
                    goBack();
                }
                console.log("放入cardLine:" + i + ", count:" + cardLine[i].count);
                var cardArr = linkedToArr(movingCard);
                for (var j = 0 ; j < cardArr.length ; j ++) {
                    cardLine[i].push(cardArr[j], 0.1);
                }
                movingCard = null;
                autoReceive();
                return;
            }
        }
        for (var i = 0 ; i < cardSite.length ; i ++) {
            if (e.clientX > cardSite[i].getBoundingClientRect().left && e.clientX < cardSite[i].getBoundingClientRect().left + cardSite[i].getBoundingClientRect().width && e.clientY > cardSite[i].getBoundingClientRect().top && e.clientY < cardSite[i].getBoundingClientRect().top + cardSite[i].getBoundingClientRect().height) {
                if (movingCard.next) {
                    goBack();
                    return;
                }
                cardSite[i].push(movingCard);
                movingCard = null;
                movingFrom = null;
                autoReceive();
                return;
            }
        }
        goBack();
        return;
    }
    document.onmousemove = function (e) {
        if (movingCard != null) {
            var pointer = movingCard;
            var num = 0;
            while(pointer) {
                pointer.style.left = (e.clientX - 20) + "px";
                pointer.style.top = (e.clientY + num * 25 - 20) + "px";
                pointer.style.zIndex = 100 + num;
                pointer = pointer.next;
                num += 1;
            }
        }
    }
}
//初始化
// 初始化
function init(){
	initCard();
	initCardSite();
	initCardReceive();
	initCardArea();
}
window.onload = function () {
    init();
}
