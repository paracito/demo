var sound = document.getElementsByTagName('audio');
var white = document.getElementsByClassName('white');
var arr = [];
// 按下按键开始播放
document.onkeydown = function(e){
	var code=e.keyCode;
	action(code);
	//添加色块
	for(var i = 0; i < 20; i++){
		var num = random(0,749);
		squ[num].style.backgroundColor = 'rgb(' + random(0,255) + ',' + random(0,255) + ','+ random(0,255) + ')';
		squ[num].style.transition = '0s 0s all ease';
		arr.push(num);
	}
}
document.onkeyup = function(e){
	for(var i = 0; i < arr.length; i++){
		squ[arr[i]].style.backgroundColor = '#000';
		squ[arr[i]].style.transition = '3s 0s all ease';
	}
	arr.splice(0,arr.length);
	var code=e.keyCode;
	end(code);
}

//播放音频，琴键变色
function rePlay(i){
	sound[i].currentTime = 0;
	sound[i].play();
	white[i].style.backgroundColor = 'rgb(204, 203, 202)';
	white[i].style.transition = '0s 0s all ease';
}
//开始
function action(code) {
	switch (code) {
		//低
		case 90:
			rePlay(0);
			break;
		case 88:
			rePlay(1);
			break;
		case 67:
			rePlay(2);
			break;
		case 86:
			rePlay(3);
			break;
		case 66:
			rePlay(4);
			break;
		case 78:
			rePlay(5);
			break;
		case 77:
			rePlay(6);
			break;
		//中
		case 65:
			rePlay(7);
			break;
		case 83:
			rePlay(8);
			break;
		case 68:
			rePlay(9);
			break;
		case 70:
			rePlay(10);
			break;
		case 71:
			rePlay(11);
			break;
		case 72:
			rePlay(12);
			break;
		case 74:
			rePlay(13);
			break;
		//高
		case 81:
			rePlay(14);
			break;
		case 87:
			rePlay(15);
			break;
		case 69:
			rePlay(16);
			break;
		case 82:
			rePlay(17);
			break;
		case 84:
			rePlay(18);
			break;
		case 89:
			rePlay(19);
			break;
		case 85:
			rePlay(20);
			break;
		default:
			break;
	}
}

//播放结束，琴键颜色恢复
function back(i){
	white[i].style.backgroundColor = '#fff';
	white[i].style.transition = '0.5s 0s all ease';
}
//结束
function end(code) {
	switch (code) {
		//低
		case 90:
			back(0);
			break;
		case 88:
			back(1);
			break;
		case 67:
			back(2);
			break;
		case 86:
			back(3);
			break;
		case 66:
			back(4);
			break;
		case 78:
			back(5);
			break;
		case 77:
			back(6);
			break;
		//中
		case 65:
			back(7);
			break;
		case 83:
			back(8);
			break;
		case 68:
			back(9);
			break;
		case 70:
			back(10);
			break;
		case 71:
			back(11);
			break;
		case 72:
			back(12);
			break;
		case 74:
			back(13);
			break;
		//高
		case 81:
			back(14);
			break;
		case 87:
			back(15);
			break;
		case 69:
			back(16);
			break;
		case 82:
			back(17);
			break;
		case 84:
			back(18);
			break;
		case 89:
			back(19);
			break;
		case 85:
			back(20);
			break;
		default:
			break;
	}
}




//色块
var rhythm = document.getElementById('rhythm');
var x = 50;
var y = 15;
for(var i = 0; i < x; i++){
	for(var j = 0; j < y; j++){
		var myDiv = document.createElement('div');
		myDiv.classList.add('squ');//动态添加class
		rhythm.appendChild(myDiv);//添加到父标签中
	}
}
var squ = document.getElementsByClassName('squ');

function random(min,max){
	return parseInt(Math.random()*(max-min)+min);
}