//点击开始，动态生成100个小格
//leftClick 没有雷显示数字-周围八个格子的雷数 周围没雷-扩散 点到雷-游戏结束
//rightClick 没有标记-进行标记 有标记-取消标记 十个都标记成功，游戏结束
//已经出现数字-点击无效果

var startBtn=document.getElementById('btn');
var right =document.getElementById('right');
var content=document.getElementById('content');
var score=document.getElementById('score');
var mineNum;
var mineOver;//剩余雷数
var block;
var mineMap=[];


bindEvent();
//点击事件集合
function bindEvent(){
	startBtn.onclick=function(){
		content.innerHTML='';//清空当前游戏
		init();
	}
	//取消鼠标右键默认事件
	content.oncontextmenu=function(){
		return false;
	}
	content.onmousedown=function(e){
		var event=e.target;
		if(e.which==1){//左键按键码为1
			leftClick(event);
		}else if(e.which==3){//右键按键码为3
			rightClick(event);
		}
	}
}
//生成100个小格
function init(){
	mineNum=10;
	mineOver=10
	score.innerHTML=mineOver;
	for(var i=0;i<10;i++){
		for(var j=0;j<10;j++){
			var con=document.createElement('div');
			con.classList.add('block');//动态添加class
			con.setAttribute('id',i+'-'+j);
			content.appendChild(con);
			mineMap.push({mine:0});
		}
	}
	//随机生成十个雷
	block=document.getElementsByClassName('block');
	while(mineNum){
		var mineIndex=Math.floor(Math.random()*100);
		if(mineMap[mineIndex].mine===0){
			mineMap[mineIndex].mine=1;
			block[mineIndex].classList.add('isLei');
			mineNum--;
		}
		
	}
	
}

function leftClick(dom){
	if (dom.classList.contains('flag')) {//contains:当先包含对应的class
		return;
	}
	var isLei=document.getElementsByClassName('isLei');
	if(dom&&dom.classList.contains('isLei')){
		for(var i=0;i<isLei.length;i++){
			isLei[i].classList.add('show');
		}
		setTimeout(function(){//延迟显示
			alert('GAMEOVER');
		},500)
	}else{
		var n=0;
		var posArr=dom&&dom.getAttribute('id').split('-');
		var posX=posArr&& +posArr[0];
		var posY=posArr&& +posArr[1];
		dom&&dom.classList.add('num');
		for(var i=posX-1;i<=posX+1;i++){
			for(var j=posY-1;j<=posY+1;j++){
				var aroundBox=document.getElementById(i+'-'+j);
				if (aroundBox&&aroundBox.classList.contains('isLei')) {
					n++;
				}
			}
		}
		dom&&(dom.innerHTML=n);
		if (n==0) {
			for(var i=posX-1;i<=posX+1;i++){
				for(var j=posY-1;j<=posY+1;j++){
					var nearBox=document.getElementById(i+'-'+j);
					if (nearBox&&nearBox.length!=0) {
						if (!nearBox.classList.contains('check')) {
							nearBox.classList.add('check');
							leftClick(nearBox);
						}
						
					}
				}
		}
		}
	}
}

function rightClick(dom){
	if (dom.classList.contains('num')) {
		return;
	}
	dom.classList.toggle('flag');//toggle:切换class
	if (dom.classList.contains('isLei')&&dom.classList.contains('flag')) {
		mineOver--;
	}
	if (dom.classList.contains('isLei')&&!dom.classList.contains('flag')) {
		mineOver++;
	}

	score.innerHTML=mineOver;
	if (mineOver==0) {
		setTimeout(function(){
			alert('YOU WIN');
		},500)
	}
}